package com.my_store.store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
