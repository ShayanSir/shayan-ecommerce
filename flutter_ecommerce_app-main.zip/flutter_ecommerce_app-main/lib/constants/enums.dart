enum MenuState { home, favourite, profile, cart }
enum PaymentMethod { visa, master, bank } 